export { default as playerIcon } from './player-icon.svg';
export { default as matchIcon } from './match-icon.svg';
export { default as teamIcon } from './team-icon.svg';
export { default as goalIcon } from './goal-icon.svg';
