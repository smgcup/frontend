import { getClient } from '@/lib/initializeApollo';
import { GetTeamsDocument, type GetTeamsQuery } from '@/graphql';
import type { Team } from '@/domains/team/contracts';
import { mapTeam } from '@/domains/team/mappers/mapTeam';

export const getAdminPlayerCreatePageData = async () => {
  const client = await getClient();

  const { data: teamsData, error: teamsError } = await client.query<GetTeamsQuery>({
    query: GetTeamsDocument,
  });

  const teamsRows = teamsData?.teams ?? [];
  const teams: Team[] = teamsRows.map(mapTeam);

  const teamsErrorMessage = teamsError
    ? typeof teamsError === 'object' && teamsError && 'message' in teamsError
      ? String((teamsError as { message?: unknown }).message ?? 'Failed to load teams.')
      : 'Failed to load teams.'
    : null;

  return { teams, teamsErrorMessage };
};
