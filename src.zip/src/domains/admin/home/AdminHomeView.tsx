import AdminHomeViewUi from './AdminHomeViewUi';

const AdminHomeView = () => {
  return <AdminHomeViewUi />;
};

export default AdminHomeView;
