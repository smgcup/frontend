export { default as HeroSection } from './HeroSection/HeroSection';
export { default as UpcomingMatchesSection } from './UpcomingMatchesSection/UpcomingMatchesSection';
export { default as TournamentStatistics } from './TournamentStatisticsSection/TournamentStatistics';
export { default as NewsSection } from './NewsSection/NewsSection';
