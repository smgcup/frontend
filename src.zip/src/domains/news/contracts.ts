export type News = {
  id: string;
  title: string;
  content: string;
  createdAt: string;
  imageUrl: string;
  category: string;
};
