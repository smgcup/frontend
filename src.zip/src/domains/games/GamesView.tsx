import GamesViewUi from './GamesViewUi';

const GamesView = () => {
  return <GamesViewUi />;
};

export default GamesView;
