import AdminAuthView from '@/domains/admin/auth/AdminAuthView';

const page = () => {
  return <AdminAuthView />;
};

export default page;
