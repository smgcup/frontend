import AdminTeamCreateView from '@/domains/admin/teams/create/AdminTeamCreateView';

const AdminTeamCreatePage = () => {
  return <AdminTeamCreateView />;
};

export default AdminTeamCreatePage;
