import React from 'react';
import AdminHomeView from '@/domains/admin/home/AdminHomeView';
const AdminPage = () => {
  return <AdminHomeView />;
};

export default AdminPage;
