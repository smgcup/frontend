import AdminNewsListView from '@/domains/admin/news/list/AdminNewsListView';

export default function AdminNewsPage() {
  return <AdminNewsListView />;
}
