import AdminNewsCreateView from '@/domains/admin/news/create/AdminNewsCreateView';

export default function AdminNewsCreatePage() {
  return <AdminNewsCreateView />;
}
