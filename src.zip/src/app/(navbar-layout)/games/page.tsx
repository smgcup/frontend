import GamesView from '@/domains/games/GamesView';

const GamesPage = () => {
  return <GamesView />;
};

export default GamesPage;
